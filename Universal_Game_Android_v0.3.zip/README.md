# Universal Game Android v0.3

## Funzioni della versione
- Interfaccia Android nero/viola.
- Tre sezioni: Libreria, Importa, Info.
- Importazione di qualsiasi file tramite selettore documenti Android.
- Memorizzazione della raccolta tra un avvio e l'altro.
- Rimozione di elementi dalla libreria.

## Cosa non fa ancora
Non esegue giochi, non emula console e non installa APK automaticamente. I motori di emulazione vanno integrati separatamente per ogni piattaforma e verificati per licenza, compatibilità e requisiti tecnici.

## Compilazione APK
1. Aprire la cartella in Android Studio recente.
2. Usare JDK 17 e Android SDK 35.
3. Attendere la sincronizzazione Gradle.
4. Selezionare Build > Build Bundle(s) / APK(s) > Build APK(s).

Application ID: `com.universalgames.app`
Versione: `0.3.0`
