package com.universalgames.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject

private val Bg = Color(0xFF090912)
private val Panel = Color(0xFF19172A)
private val Purple = Color(0xFF9B72FF)
private val Muted = Color(0xFFB9B3CC)

data class GameFile(val name: String, val type: String, val uri: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { UniversalGameApp() }
    }
}

@Composable
fun UniversalGameApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("universal_game", 0) }
    var files by remember { mutableStateOf(loadFiles(prefs.getString("files", "[]") ?: "[]")) }
    var notice by remember { mutableStateOf("La tua raccolta, in un unico posto.") }
    var selectedTab by remember { mutableIntStateOf(0) }

    fun save(items: List<GameFile>) {
        files = items
        prefs.edit().putString("files", JSONArray().apply {
            items.forEach { f ->
                put(JSONObject().apply {
                    put("name", f.name); put("type", f.type); put("uri", f.uri)
                })
            }
        }.toString()).apply()
    }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val additions = uris.mapNotNull { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            val doc = DocumentFile.fromSingleUri(context, uri)
            val name = doc?.name ?: "File"
            val ext = name.substringAfterLast('.', "").uppercase().ifBlank { "FILE" }
            GameFile(name, ext, uri.toString())
        }
        val combined = (files + additions).distinctBy { it.uri }
        save(combined)
        notice = if (additions.isEmpty()) "Nessun nuovo file importato." else "${additions.size} file aggiunti alla raccolta."
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Gamepad, contentDescription = null) },
                        label = { Text("Libreria") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.FolderOpen, contentDescription = null) },
                        label = { Text("Importa") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        label = { Text("Info") }
                    )
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().background(Bg).padding(padding).padding(horizontal = 18.dp)
            ) {
                Spacer(Modifier.height(18.dp))
                Text("UNIVERSAL GAME", color = Purple, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("Il tuo archivio di giochi", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(18.dp))

                when (selectedTab) {
                    0 -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("LA MIA LIBRERIA", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Spacer(Modifier.weight(1f))
                            Text("${files.size} file", color = Muted, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(notice, color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        if (files.isEmpty()) {
                            EmptyPanel(
                                title = "Ancora nessun gioco",
                                subtitle = "Importa file dal telefono per iniziare."
                            )
                        } else {
                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(files, key = { it.uri }) { file ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = Panel),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Row(
                                            Modifier.fillMaxWidth().padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Surface(color = Color(0xFF30254D), shape = RoundedCornerShape(10.dp)) {
                                                Text(file.type.take(5), Modifier.padding(9.dp), color = Purple, fontWeight = FontWeight.Bold)
                                            }
                                            Spacer(Modifier.width(12.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(file.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                                                Text("Formato ${file.type}", color = Muted, fontSize = 11.sp)
                                            }
                                            IconButton(onClick = {
                                                save(files.filterNot { it.uri == file.uri })
                                                notice = "File rimosso dalla libreria."
                                            }) {
                                                Icon(Icons.Default.Delete, contentDescription = "Rimuovi", tint = Muted)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(18.dp)) {
                                Text("IMPORTA I TUOI FILE", color = Purple, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Seleziona file dal dispositivo: APK, ZIP, RAR, 7Z, ISO, BIN, CUE, ROM e altri formati.")
                                Spacer(Modifier.height(16.dp))
                                Button(
                                    onClick = { picker.launch(arrayOf("*/*")) },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("SCEGLI FILE") }
                                Spacer(Modifier.height(8.dp))
                                Text("La selezione copia nella libreria il collegamento al file, non il file stesso.", color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                    else -> {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(18.dp)) {
                                Text("UNIVERSAL GAME v0.3", color = Purple, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Questa versione gestisce la raccolta dei file e ricorda gli elementi importati.")
                                Spacer(Modifier.height(12.dp))
                                Text("L'avvio dei giochi non è ancora incluso: ogni sistema (PSP, PlayStation, Nintendo, ecc.) richiede un motore di emulazione dedicato e compatibile.", color = Muted, fontSize = 12.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("Usa solo giochi, BIOS e firmware che hai diritto di utilizzare.", color = Muted, fontSize = 12.sp)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun EmptyPanel(title: String, subtitle: String) {
    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Gamepad, contentDescription = null, tint = Purple, modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(12.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

private fun loadFiles(raw: String): List<GameFile> = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).map { i ->
        val obj = array.getJSONObject(i)
        GameFile(obj.getString("name"), obj.getString("type"), obj.getString("uri"))
    }
}.getOrDefault(emptyList())
